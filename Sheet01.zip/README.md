# data_science


This project uses pipenv to generate a virtual environment, it can be installed through pip or apt-get.

We are utilizing the pipfile from https://git.uibk.ac.at/informatik/dbis/dbis-teaching/data-engineering-analytics-notebooks. It requires python3.10 to run.

When in this directory, run **pipenv install** to create the virtual environment from the pipfile (it lists all the required python modules). If you need a shell with the activated virtual environment, type **pipenv shell**. 

Make sure to select the virtual environment in your jupyter notebook as well!


