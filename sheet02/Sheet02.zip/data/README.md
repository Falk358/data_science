Dataset adapted from https://github.com/CJOlsen/perfect-meal-win

	- extracted baked goods
	- added more specific group types
	- added null values & outlier
